.. _advanced-topics:

Advanced topics
***************

This section contains some more detailed explanations on the internal workings of *WinAppDbg* and how to perform more complex tasks with it.

.. toctree::
   :maxdepth: 3

   Signature
   HowLabelsWork
   HowBreakpointsWork
